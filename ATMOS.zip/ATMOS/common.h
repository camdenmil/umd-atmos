/*
 * common.h
 *
 * Created: 10/10/2014 11:47:44 AM
 *  Author: Camden
 */ 


#ifndef COMMON_H_
#define COMMON_H_

#include <stdint.h>
#include "util.h"


#endif /* COMMON_H_ */